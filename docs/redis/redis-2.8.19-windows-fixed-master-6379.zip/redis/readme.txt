
===================================
前言：

建议使用下面方法二，直接解压到相应的位置 D:\server\ 下 ，就不需要更改配置（包括端口和文件位置）。
之后双击 D:\server\redis\redis-bat\startMaster.vbe 开始启动就只有一个端口为 6379 的 redis 实例。
（可能需要允许系统的运行权限提示，或加到杀毒软件的白名单去）。

如果使用 *.vbe 的确没有正常使用，可考虑双击 redis-server-master.bat 来运行，同时可能有助于排查问题
===================================



解压到本地开始使用前，先处理 conf 里 5 个配置文件的 dir 值，列表如下：

master.conf
    dir "D:\\server\\redis\\redis-bat"
slave1.conf
    dir "D:\\server\\redis\\redis-bat"
slave2.conf
    dir "D:\\server\\redis\\redis-bat"
sentinel1.conf
    dir "D:\\server\\redis\\sentinel-dir"
sentinel2.conf
    dir "D:\\server\\redis\\sentinel-dir"

方式一，编辑 5 个配置文件，改为本地放置 redis 目录的对应值；也可方式二，直接按上面的路径对应放置 redis 目录。

然后再双击 \redis\redis-bat\startAll.vbe 就可以在本地启动全部实例和哨兵等，启动完成大概半分钟。

-----------------------------
Windows 配置主从redis

在同一台机器上配置主从redis服务（master-slave）。

这个测试的案例是：master服务的端口是6379 ，slave服务器的端口是 6380，IP:127.0.0.1。

第一步：下载redis服务。下载windows版本的.可以下载下来。如果你的机器是linux，那请换个地址下载，本文仅对windows下部署做出说明

第二步：复制出一个 redis.windows.conf 文件，命名为：redis_slave.conf （对应主服务器和从服务器的配置文件）

第三步：redis.windows.conf 可以修改maxheap和port； redis_slave.conf  文件里我们将端口号修改成 6380，并且将 slaveof 修改为：　slaveof 127.0.0.1 6379（设置master服务器地址）

第四步：运行windows命令行工具（或者开始输入框里输入 cmd） ，进入命令行页面，进入redis-server目录下

第五步： 首先启动master服务：输入命令：redis-server  redis.conf （执行server运行对应的config配置文件）。然后再启动一个cmd命令行页面，启动slave服务,命令：redis- server  redis_slave.conf

第六步：启动redis-cli客户端程序。在cmd命令行中输入：redis-cli -p 6379  。再启动一个cmd命令行页面，输入： redis-cli -p 6380。分别启动两个不同端口的客户端（对应两个server服务）

第七步：在redis-cli -p 6379 命令行页面，输入 set key “test” ，则可以在另一个cmd命令行页面（6380），输入命令：get key，则可以得到：test

通过master 和slave之间的sync命令，数据复制成功，分布式数据存储实验完成。

备注：启动redis_cli 客户端默认是以6379端口打开的，当我们想修改客户端的默认端口时候，可以用上面的命令修改为我们想要的端口号


启动主服务
（图1）

启动主客户端
（图2）

启动从服务
（图3）

启动从客户端
（图4）

测试

主客户端
（图5）

从客户端
（图6）

创建sentinel.conf

port 63794
maxheap 512000000
daemonize yes
sentinel monitor mymaster 127.0.0.1 63791 2
sentinel down-after-milliseconds mymaster 60000
sentinel failover-timeout mymaster 180000
sentinel parallel-syncs mymaster 1

启动
（图7）
